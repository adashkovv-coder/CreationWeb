/* eslint-disable*/
import React, {useEffect, useState} from 'react'
import styles from './index.module.scss'

export type IGeneratedComponent = {}

export default function GeneratedComponent(props: IGeneratedComponent) {
  return (
    <div className={styles.page}>
      <img src={require('./assets/image_1.png')} className={styles.image} />
      <img src={require('./assets/image_2.png')} className={styles.image1} />
      <img src={require('./assets/image_3.png')} className={styles.image2} />
      <img src={require('./assets/image_4.png')} className={styles.image3} />
      <img src={require('./assets/image_5.png')} className={styles.image4} />
      <img src={require('./assets/image_6.png')} className={styles.image5} />
      <img src={require('./assets/image_7.png')} className={styles.image6} />
      <img src={require('./assets/image_8.png')} className={styles.image7} />
      <div className={styles.wrap}>
        <div className={styles.image8}>
          <img
            src={require('./assets/image_10.png')}
            className={styles.image9}
          />
          <img
            src={require('./assets/image_11.png')}
            className={styles.image10}
          />
          <div className={styles.container}>
            <div className={styles.content}>
              <img
                src={require('./assets/image_12.png')}
                className={styles.image13}
              />
              <img
                src={require('./assets/image_13.png')}
                className={styles.image12}
              />
            </div>
            <img
              src={require('./assets/image_14.png')}
              className={styles.image11}
            />
          </div>
        </div>
      </div>
    </div>
  )
}
