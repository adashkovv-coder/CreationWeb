/* eslint-disable*/
import React, {useEffect, useState} from 'react'
import styles from './index.module.scss'

export type IGeneratedComponent = {}

export default function GeneratedComponent(props: IGeneratedComponent) {
  return (
    <div className={styles.page}>
      <div className={styles.wrap}>
        <img src={require('./assets/image_1.png')} className={styles.image} />
        <div className={styles.container}>
          <img
            src={require('./assets/image_2.png')}
            className={styles.image1}
          />
          <img
            src={require('./assets/image_3.png')}
            className={styles.image2}
          />
        </div>
      </div>
    </div>
  )
}
