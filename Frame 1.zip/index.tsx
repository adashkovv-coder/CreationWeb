/* eslint-disable*/
import React, {useEffect, useState} from 'react'
import styles from './index.module.scss'

export type IGeneratedComponent = {}

export default function GeneratedComponent(props: IGeneratedComponent) {
  return <img src={require('./assets/image_1.png')} className={styles.image} />
}
